package com.example.demo;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Project
{
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)

int id;
String projectName;
@OneToMany(cascade = CascadeType.ALL)
List<Tasks> task;
public Project() {
	super();
	// TODO Auto-generated constructor stub
}
public Project(int id, String projectName, List<Tasks> task) {
	super();
	this.id = id;
	this.projectName = projectName;
	this.task = task;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getProjectName() {
	return projectName;
}
public void setProjectName(String projectName) {
	this.projectName = projectName;
}
public List<Tasks> getTask() {
	return task;
}
public void setTask(List<Tasks> task) {
	this.task = task;
}
@Override
public String toString() {
	return "Project [id=" + id + ", projectName=" + projectName + ", task=" + task + "]";
}

}
